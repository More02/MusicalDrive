package com.example.commercialdirector.myitschool.models;


import java.util.ArrayList;

public class Musics {
    private ArrayList<Music> musics;

    public Musics() {

    }

    public ArrayList<Music> getMusicses() {
        return musics;
    }

    public void setMusicses(ArrayList<Music> musics) {
        this.musics = musics;
    }
}
