package com.example.commercialdirector.myitschool.models;


import java.util.ArrayList;

public class Likes
{
    private ArrayList<Likei> likes;

    public Likes() {

    }

    public ArrayList<Likei> getLikes() { return likes; }

    public void setLikes(ArrayList<Likei> likes) { this.likes = likes; }

}
