package com.example.commercialdirector.myitschool.models;


import java.util.ArrayList;

public class News {
    private ArrayList<New> news;


        public ArrayList<New> getNews() { return news; }

    public void setNews(ArrayList<New> news) { this.news = news; }

    public News () {

    }

}
