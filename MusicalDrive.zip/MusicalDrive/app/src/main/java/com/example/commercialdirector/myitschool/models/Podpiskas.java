package com.example.commercialdirector.myitschool.models;


import java.util.ArrayList;

public class Podpiskas {
    private ArrayList<Podpiska> podpiskas;

    public Podpiskas (){

    }

    public ArrayList<Podpiska> getPodpiskas() {
        return podpiskas;
    }

    public void setPodpiskas(ArrayList<Podpiska> podpiskas) {
        this.podpiskas = podpiskas;
    }
}
