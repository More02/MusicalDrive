package com.example.commercialdirector.myitschool.connection;


public class AppConfig {


    public static String URL_LOGIN = "http://192.168.1.2/login.php";


    public static String URL_REGISTER = "http://192.168.1.2/register.php";

    public static String BASE_URL = "http://192.168.1.2/";

    public static String BASE_PUBLIC = "http://192.168.1.2/public/";
}
